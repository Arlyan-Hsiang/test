using System;
using Xunit;
using XmlValidator;

namespace XmlValidator.Tests
{
    public class SimpleXmlValidatorTests
    {
        [Fact]
        public void TestValidXml()
        {
            Assert.Equal("Valid", SimpleXmlValidator.DetermineXml("<Design><Code>hello world</Code></Design>"));
        }

        [Fact]
        public void TestInvalidXmlExtraClosingTag()
        {
            Assert.Equal("Invalid", SimpleXmlValidator.DetermineXml("<Design><Code>hello world</Code></Design><People>"));
        }

        [Fact]
        public void TestInvalidXmlMisnested()
        {
            Assert.Equal("Invalid", SimpleXmlValidator.DetermineXml("<People><Design><Code>hello world</People></Code></Design>"));
        }

        [Fact]
        public void TestInvalidXmlAttributes()
        {
            Assert.Equal("Invalid", SimpleXmlValidator.DetermineXml("<People age=\"1\">hello world</People>"));
        }
        [Fact]
        public void TestValidXmlAttributes()
        {
            Assert.Equal("Invalid", SimpleXmlValidator.DetermineXml("<People>hello world</People"));
        }
    }
}
