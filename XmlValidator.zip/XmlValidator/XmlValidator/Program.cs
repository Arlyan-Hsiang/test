﻿using System;

namespace XmlValidator
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("Usage: XmlValidator <xml-string>");
                return;
            }

            string xml = args[0];
            string result = SimpleXmlValidator.DetermineXml(xml);
            Console.WriteLine(result);
        }
    }
}
